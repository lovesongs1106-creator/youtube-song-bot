# Facebook → second YouTube channel workflow

This adds `/upload` without changing the existing `/new` music workflow.
Use only Facebook videos you are authorized to download, edit and upload. The worker does not bypass DRM, private-content controls, login, paywalls or platform security.

## Files

- `facebook_video.py`: HTTPS Facebook URL validation, timestamp parsing, yt-dlp download, FFmpeg trim/normalization/concat.
- `telegram_bot.py`: `/upload`, `/upload_force`, `/status`, and `/cancel JOB-ID`.
- `github_worker.py`: Facebook job branch and separate second-channel OAuth uploader.
- `.github/workflows/render-upload.yml`: second-channel secrets and fixed outro configuration.
- `assets/outro.mp4`: permanent outro asset (you must add your authorized file here).

## Required GitHub Secrets

Keep existing first-channel secrets unchanged:

- `TELEGRAM_BOT_TOKEN`
- `YOUTUBE_TOKEN_JSON`
- `GOOGLE_CLIENT_SECRETS_JSON` (existing, if used)

Add these **separate** secrets for the second channel:

- `YOUTUBE_SECOND_CLIENT_ID`
- `YOUTUBE_SECOND_CLIENT_SECRET`
- `YOUTUBE_SECOND_REFRESH_TOKEN`

The second worker path never reads `YOUTUBE_TOKEN_JSON`. The refresh token must be created with the second channel's Google OAuth client. Before production, run one private test; the completion message displays the resolved channel title. If it is not the second channel, stop and replace the second refresh token—do not publish.

## Repository variables

- `YOUTUBE_TARGET_CHANNEL=second` (default)
- `YOUTUBE_VISIBILITY=private` (default; allowed `private`, `unlisted`, `public`)
- `OUTRO_ASSET_PATH=assets/outro.mp4` (default)
- Existing `VIDEO_WIDTH`, `VIDEO_HEIGHT`, `VIDEO_FPS`, `FFMPEG_PRESET` remain supported by the old flow.

## Telegram commands

```text
/upload https://www.facebook.com/... 
/upload https://www.facebook.com/... trim 00:02:15-00:38:42
/upload https://www.facebook.com/... trim 02:15-38:42
/upload_force https://www.facebook.com/...
/status JOB-...
/cancel JOB-...
```

Invalid hosts, non-HTTPS URLs, malformed timestamps, reversed ranges, and duplicate URLs are rejected on Render. Duplicate identity is a SHA-256 hash of the normalized URL. `/upload_force` deliberately bypasses only duplicate protection; it does not bypass Facebook access controls.

## Processing

GitHub Actions creates an isolated `job_workspace/<JOB-ID>/` directory containing `source.mp4`, `work/`, `final.mp4`, `thumbnail.jpg`, and `metadata.json`. The source is downloaded with `yt-dlp`, optionally trimmed, normalized to 1280×720 H.264/AAC, concatenated with `assets/outro.mp4`, metadata is generated from the actual Facebook title, then uploaded privately to the second channel. The successful job removes the large workspace; failed jobs retain only useful small logs/metadata where possible.

Progress and failure messages are sent to Telegram. A successful result includes title, trim/full-video choice, outro status, resolved target channel title, visibility and YouTube URL.

## Safe rollout

1. Add your authorized `assets/outro.mp4` to the repository.
2. Add the three second-channel secrets in GitHub Settings → Secrets and variables → Actions.
3. Set repository variables to `YOUTUBE_TARGET_CHANNEL=second` and `YOUTUBE_VISIBILITY=private`.
4. Merge/upload the changed files; do not deploy yet.
5. Test an authorized short public Facebook video with no trim.
6. Confirm the result says the expected second-channel title and is **Private**.
7. Test a short trim and verify the outro is present.
8. Test duplicate rejection and `/upload_force`.
9. Test a deliberately invalid URL and confirm no GitHub job is dispatched.

## Rollback

Remove the `/upload`, `/upload_force`, `/status`, and `/cancel_job` handler lines plus the Facebook branch/import from `telegram_bot.py` and `github_worker.py`, or restore the previous stable commit. Existing `/new`, `/audio_retry`, trend approval, first-channel OAuth, and `YOUTUBE_TOKEN_JSON` remain separate.
