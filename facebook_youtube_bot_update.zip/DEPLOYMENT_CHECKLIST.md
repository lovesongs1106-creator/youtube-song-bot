# Deployment Checklist - YouTube Song Automation Bot

## GitHub Secrets Required
| Name                        | Purpose                              | Required |
|----------------------------|--------------------------------------|----------|
| GITHUB_TOKEN               | Trigger GitHub Actions               | Yes      |
| YOUTUBE_TOKEN_JSON         | YouTube upload authentication        | Yes      |
| TELEGRAM_BOT_TOKEN         | Send messages from GitHub Actions    | Yes      |
| GOOGLE_CLIENT_SECRETS_JSON | OAuth client (optional for refresh)  | Optional |

## Render Environment Variables Required
| Name                        | Purpose                              | Required |
|----------------------------|--------------------------------------|----------|
| TELEGRAM_BOT_TOKEN         | Bot API access                       | Yes      |
| BASE_URL                   | Webhook + OAuth callback             | Yes      |
| GOOGLE_CLIENT_SECRETS_JSON | Google OAuth                         | Yes      |
| AUTHORIZED_TELEGRAM_USER_ID| Restrict access                      | Yes      |
| DEFAULT_PRIVACY            | Default = private                    | Yes      |
| USE_GITHUB_WORKER          | Route work to GitHub Actions         | Yes      |
| GITHUB_REPO                | Repository for dispatch              | Yes      |
| GITHUB_TOKEN               | Trigger workflows                    | Yes      |
| GITHUB_EVENT_TYPE          | Event type                           | Yes      |

## Feature Flags (Render + GitHub)
| Name                        | Default | Purpose |
|----------------------------|---------|---------|
| ENABLE_TREND_AGENT         | false   | Trend discovery |
| ENABLE_RECOMMENDATIONS     | false   | Daily Telegram report |
| ENABLE_APPROVE_WORKFLOW    | false   | Approve button handling |

## Rollback
- Disable all three feature flags
- Or switch to branch: backup-stable-before-automation-upgrade

## GitHub Actions Workflow
- File must exist: `.github/workflows/render-upload.yml`
- Must have `repository_dispatch` trigger

## Telegram Bot
- Webhook must be configured
- Bot must have privacy mode disabled (for commands)