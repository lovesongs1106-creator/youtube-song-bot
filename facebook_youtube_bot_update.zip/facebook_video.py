"""Authorized Facebook video download and FFmpeg processing helpers.

This module deliberately uses yt-dlp only for URLs that are publicly/legitimately
accessible to the worker. It does not provide cookies, DRM, login, paywall, or
access-control bypasses.
"""
from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
from pathlib import Path
from typing import Any

from bot import generate_seo_metadata, generate_thumbnail

FB_HOSTS = {"facebook.com", "www.facebook.com", "m.facebook.com", "fb.watch"}
TIME_RE = re.compile(r"^(?:(\d+):)?(\d{1,2}):(\d{2})$")


def validate_facebook_url(url: str) -> bool:
    from urllib.parse import urlparse
    p = urlparse(url.strip())
    return p.scheme == "https" and (p.hostname or "").lower().rstrip(".") in FB_HOSTS and bool(p.path)


def parse_trim(value: str | None) -> tuple[float, float] | None:
    if not value:
        return None
    text = value.strip().replace(" ", "")
    if "-" not in text:
        raise ValueError("Trim format must be HH:MM:SS-HH:MM:SS or MM:SS-MM:SS.")
    left, right = text.split("-", 1)

    def seconds(item: str) -> float:
        m = TIME_RE.fullmatch(item)
        if not m:
            raise ValueError(f"Invalid timestamp: {item}")
        h = int(m.group(1) or 0)
        minute = int(m.group(2))
        second = int(m.group(3))
        if minute >= 60 or second >= 60:
            raise ValueError(f"Invalid timestamp: {item}")
        return h * 3600 + minute * 60 + second

    start, end = seconds(left), seconds(right)
    if start < 0 or end <= start:
        raise ValueError("Trim end time must be greater than start time.")
    return start, end


def run(cmd: list[str]) -> None:
    proc = subprocess.run(cmd, text=True, capture_output=True)
    if proc.returncode:
        detail = (proc.stderr or proc.stdout)[-1200:]
        raise RuntimeError(f"FFmpeg failed: {detail}")


def download_facebook_video(url: str, output: Path) -> Path:
    if not validate_facebook_url(url):
        raise ValueError("Only a valid HTTPS Facebook video URL is accepted.")
    if not shutil.which("yt-dlp"):
        raise RuntimeError("yt-dlp is not installed on the worker.")
    output.parent.mkdir(parents=True, exist_ok=True)
    template = str(output.with_suffix(".%(ext)s"))
    cmd = [
        "yt-dlp", "--no-playlist", "--restrict-filenames",
        "-f", "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b",
        "--merge-output-format", "mp4", "-o", template, url,
    ]
    proc = subprocess.run(cmd, text=True, capture_output=True, timeout=900)
    if proc.returncode:
        # Do not suggest authentication bypasses. The owner can use a legitimately
        # accessible public URL or stop the job.
        raise RuntimeError("Facebook download failed for this accessible URL. The video may be private, restricted, or unavailable.")
    candidates = sorted(output.parent.glob(output.stem + ".*"))
    candidates = [p for p in candidates if p.suffix.lower() not in {".part", ".ytdl"}]
    if not candidates:
        raise RuntimeError("Facebook downloader produced no video file.")
    if candidates[0] != output:
        candidates[0].replace(output)
    return output


def process_video(source: Path, outro: Path, final: Path, trim: tuple[float, float] | None, workdir: Path) -> None:
    if not outro.exists():
        raise FileNotFoundError(f"Fixed outro asset missing: {outro}. Upload your permanent outro at this path.")
    workdir.mkdir(parents=True, exist_ok=True)
    main = workdir / "main.mp4"
    outro_norm = workdir / "outro.mp4"
    if trim:
        start, end = trim
        run(["ffmpeg", "-y", "-ss", str(start), "-i", str(source), "-t", str(end - start),
             "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30",
             "-c:v", "libx264", "-preset", os.getenv("FFMPEG_PRESET", "veryfast"), "-c:a", "aac", "-ar", "44100", "-ac", "2", str(main)])
    else:
        run(["ffmpeg", "-y", "-i", str(source),
             "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30",
             "-c:v", "libx264", "-preset", os.getenv("FFMPEG_PRESET", "veryfast"), "-c:a", "aac", "-ar", "44100", "-ac", "2", str(main)])
    run(["ffmpeg", "-y", "-i", str(outro),
         "-vf", "scale=1280:720:force_original_aspect_ratio=decrease,pad=1280:720:(ow-iw)/2:(oh-ih)/2,setsar=1,fps=30",
         "-c:v", "libx264", "-preset", os.getenv("FFMPEG_PRESET", "veryfast"), "-c:a", "aac", "-ar", "44100", "-ac", "2", str(outro_norm)])
    concat = workdir / "concat.txt"
    concat.write_text(f"file '{main.resolve().as_posix()}'\nfile '{outro_norm.resolve().as_posix()}'\n", encoding="utf-8")
    run(["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", str(concat),
         "-c", "copy", str(final)])


def video_title(url: str) -> str:
    try:
        proc = subprocess.run(["yt-dlp", "--no-playlist", "--print", "%(title)s", "--skip-download", url], capture_output=True, text=True, timeout=90)
        title = (proc.stdout or "").strip().splitlines()[0] if proc.returncode == 0 else ""
        return title[:150] or "Facebook Video"
    except Exception:
        return "Facebook Video"
