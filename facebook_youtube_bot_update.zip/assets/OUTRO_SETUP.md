Place the permanent authorized outro video at assets/outro.mp4 before production.
The GitHub worker reads OUTRO_ASSET_PATH (default: assets/outro.mp4).
Do not commit secrets or copyrighted material without permission.
